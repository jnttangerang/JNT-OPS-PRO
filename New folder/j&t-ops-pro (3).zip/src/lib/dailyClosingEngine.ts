import { 
  calculateFinancialSummary, 
  calculateDailyFinancial, 
  isTransactionValidForFinance 
} from "./financialEngine";
import { 
  reconcileDaily, 
  logReconciliationExecution 
} from "./reconciliationEngine";
import { 
  syncReconciliationExceptions, 
  getClosingReconciliationStatus, 
  getExceptions 
} from "./reconciliationReviewEngine";
import { logAuditEvent } from "./auditTrailEngine";
import { getSettlementRecord } from "./settlementEngine";

export type ClosingState = "OPEN" | "VALIDATING" | "READY" | "CLOSED" | "BLOCKED" | "REOPENED";

export interface ActorInfo {
  actor_id: string;
  actor_name?: string;
  actor_role?: string;
}

export interface DailyClosingRecord {
  closing_id: string;
  outlet_id: string;
  tanggal: string;
  status: ClosingState;

  // Single Source of Truth: Financial Engine
  total_customer: number;
  total_owner_deposit: number;
  total_outlet_cash: number;
  total_rounding: number;
  transaction_count: number;
  valid_financial_transaction_count: number;
  cancelled_transaction_count: number;

  // Setoran Validation Summary
  setoran_required: number;
  setoran_actual: number;
  setoran_variance: number;
  setoran_status: "MATCHED" | "MISMATCH" | "UNAPPROVED" | "MISSING" | "OK";

  // Reconciliation Summary
  reconciliation_status: "MATCHED" | "WARNING" | "MISMATCH" | "CRITICAL";
  open_exceptions_count: number;
  open_critical_count: number;
  open_error_count: number;
  open_warning_count: number;

  // Audit Metadata & State Machine
  validated_at?: string;
  validated_by?: string;
  closed_at?: string;
  closed_by?: string;
  reopened_at?: string;
  reopened_by?: string;
  reopen_reason?: string;
  notes?: string;
  blocking_reasons?: string[];

  created_at: string;
  updated_at: string;
}

function ensureClosingTable(db: any): DailyClosingRecord[] {
  if (!db.DailyClosing) {
    db.DailyClosing = [];
  }
  if (!db.DailyClosings) {
    db.DailyClosings = db.DailyClosing;
  }
  return db.DailyClosing;
}

export function generateClosingId(outletId: string, tanggal: string): string {
  const cleanOutlet = (outletId || "GLOBAL").trim().toUpperCase();
  const cleanDate = (tanggal || new Date().toISOString().split("T")[0]).trim();
  return `CLS-${cleanOutlet}-${cleanDate}`;
}

export function getDailyClosingRecord(db: any, outletId: string, tanggal: string): DailyClosingRecord | null {
  const list = ensureClosingTable(db);
  const closingId = generateClosingId(outletId, tanggal);
  const found = list.find((item: DailyClosingRecord) => item.closing_id === closingId || (item.outlet_id === outletId && item.tanggal === tanggal));
  return found || null;
}

export function validateDailyClosing(
  db: any,
  params: {
    outlet_id: string;
    tanggal: string;
    actor: ActorInfo;
  }
): { status: "success" | "blocked" | "error"; error_code?: string; message: string; data?: DailyClosingRecord; blocking_reasons?: string[] } {
  const { outlet_id, tanggal, actor } = params;

  if (!outlet_id) {
    return { status: "error", error_code: "INVALID_PARAM", message: "outlet_id wajib diisi." };
  }
  if (!tanggal) {
    return { status: "error", error_code: "INVALID_PARAM", message: "tanggal wajib diisi." };
  }

  const list = ensureClosingTable(db);
  const closingId = generateClosingId(outlet_id, tanggal);
  let existing = list.find((r) => r.closing_id === closingId);

  if (existing && existing.status === "CLOSED") {
    return {
      status: "error",
      error_code: "PERIOD_ALREADY_CLOSED",
      message: `Periode daily closing '${tanggal}' untuk outlet '${outlet_id}' sudah dalam status CLOSED. Reopen terlebih dahulu untuk memproses ulang.`,
      data: existing
    };
  }

  const now = new Date().toISOString();

  // Log audit event for closing started
  logAuditEvent(db, {
    event_type: "CLOSING_STARTED",
    action: "START_DAILY_CLOSING_VALIDATION",
    entity_type: "DAILY_CLOSING",
    entity_id: closingId,
    outlet_id,
    result: "SUCCESS",
    actor_id: actor.actor_id,
    actor_name: actor.actor_name,
    actor_role: actor.actor_role,
    metadata: { outlet_id, tanggal }
  });

  // 1. Single Source of Truth Financial Calculation for outlet + tanggal
  const allTx = db.MASTER_TRANSAKSI || [];
  const outletDateTx = allTx.filter((tx: any) => {
    const d = tx.created_at ? tx.created_at.split("T")[0] : (tx.tanggal_transaksi || "");
    return tx.outlet_id === outlet_id && d === tanggal;
  });

  const dailyFin = calculateDailyFinancial(outletDateTx);

  let total_rounding = 0;
  let valid_financial_transaction_count = 0;
  let cancelled_transaction_count = 0;

  for (const tx of outletDateTx) {
    if (isTransactionValidForFinance(tx)) {
      valid_financial_transaction_count++;
      const summary = calculateFinancialSummary(tx);
      total_rounding += summary.rounding;
    } else {
      cancelled_transaction_count++;
    }
  }

  // 2. Reconciliation Execution & Exception Review Validation
  const reconRes = reconcileDaily(db, tanggal, outlet_id);
  logReconciliationExecution(db, reconRes, actor.actor_id || "SYSTEM");
  syncReconciliationExceptions(db, reconRes);

  const reconClosingStatus = getClosingReconciliationStatus(db, outlet_id, tanggal);

  // 3. Setoran Owner Validation
  const allSetoran = db.Master_Setoran || db.SetoranData || db.Setoran || [];
  const activeSetoran = allSetoran.filter((s: any) => {
    const sDate = s.tanggal || s.date || "";
    return s.outlet_id === outlet_id && sDate === tanggal && s.status !== "DITOLAK";
  });

  const setoran_required = dailyFin.total_owner;
  let setoran_actual = 0;
  for (const s of activeSetoran) {
    setoran_actual += Number(s.nominal || s.jumlah_setor || s.total_setor || 0);
  }

  const setoran_variance = Math.abs(setoran_required - setoran_actual);

  let setoran_status: "MATCHED" | "MISMATCH" | "UNAPPROVED" | "MISSING" | "OK" = "OK";
  if (setoran_required === 0) {
    setoran_status = "OK";
  } else if (activeSetoran.length === 0) {
    setoran_status = "MISSING";
  } else {
    const hasUnapproved = activeSetoran.some((s: any) => 
      s.status === "PENDING" || 
      (s.status !== "DISETUJUI" && s.status !== "APPROVED" && s.approval_status !== "APPROVED")
    );
    if (hasUnapproved) {
      setoran_status = "UNAPPROVED";
    } else if (setoran_variance > 0.01) {
      setoran_status = "MISMATCH";
    } else {
      setoran_status = "MATCHED";
    }
  }

  // 4. Compile Blocking Reasons
  const blocking_reasons: string[] = [];

  if (reconClosingStatus.open_critical_count > 0) {
    blocking_reasons.push(`Terdapat ${reconClosingStatus.open_critical_count} CRITICAL reconciliation exception belum selesai.`);
  }

  if (reconClosingStatus.open_error_count > 0) {
    blocking_reasons.push(`Terdapat ${reconClosingStatus.open_error_count} ERROR reconciliation exception belum selesai.`);
  }

  if (reconRes.variance_total > 0.01) {
    blocking_reasons.push(`Terdapat selisih finansial rekonsiliasi sebesar Rp ${reconRes.variance_total.toLocaleString('id-ID')}.`);
  }

  if (setoran_required > 0) {
    if (setoran_status === "MISSING") {
      blocking_reasons.push(`Setoran Owner untuk tanggal '${tanggal}' belum diinput di Master_Setoran.`);
    } else if (setoran_status === "UNAPPROVED") {
      blocking_reasons.push("Setoran Owner belum disetujui (status masih PENDING).");
    } else if (setoran_status === "MISMATCH") {
      blocking_reasons.push(`Selisih setoran Owner: Wajib Setor Rp ${setoran_required.toLocaleString('id-ID')} vs Disetor Rp ${setoran_actual.toLocaleString('id-ID')}.`);
    }
  }

  // Settlement Engine Check
  const stlRecord = getSettlementRecord(db, outlet_id, tanggal);
  if (stlRecord) {
    if (["UNSETTLED", "PENDING_DEPOSIT", "MISMATCH", "UNDER_REVIEW", "REJECTED"].includes(stlRecord.status)) {
      blocking_reasons.push(`Settlement Keuangan Owner belum selesai/disetujui (status: ${stlRecord.status}).`);
    }
  }

  const isBlocked = blocking_reasons.length > 0;
  const finalStatus: ClosingState = isBlocked ? "BLOCKED" : "READY";

  // Construct or update DailyClosingRecord idempotently
  const record: DailyClosingRecord = {
    closing_id: closingId,
    outlet_id,
    tanggal,
    status: finalStatus,

    total_customer: dailyFin.total_customer,
    total_owner_deposit: dailyFin.total_owner,
    total_outlet_cash: dailyFin.total_outlet,
    total_rounding,
    transaction_count: outletDateTx.length,
    valid_financial_transaction_count,
    cancelled_transaction_count,

    setoran_required,
    setoran_actual,
    setoran_variance,
    setoran_status,

    reconciliation_status: reconRes.status,
    open_exceptions_count: reconClosingStatus.open_exceptions_count,
    open_critical_count: reconClosingStatus.open_critical_count,
    open_error_count: reconClosingStatus.open_error_count,
    open_warning_count: reconClosingStatus.open_warning_count,

    validated_at: now,
    validated_by: actor.actor_id || actor.actor_name || "SYSTEM",
    blocking_reasons: isBlocked ? blocking_reasons : [],
    created_at: existing ? existing.created_at : now,
    updated_at: now
  };

  let targetRecord: DailyClosingRecord;
  if (!existing) {
    targetRecord = record;
    list.push(targetRecord);
  } else {
    Object.assign(existing, record);
    targetRecord = existing;
  }

  // Audit trail event
  if (isBlocked) {
    logAuditEvent(db, {
      event_type: "CLOSING_BLOCKED",
      action: "VALIDATE_DAILY_CLOSING",
      entity_type: "DAILY_CLOSING",
      entity_id: closingId,
      outlet_id,
      result: "FAILED",
      reason: blocking_reasons.join(" | "),
      actor_id: actor.actor_id,
      actor_name: actor.actor_name,
      actor_role: actor.actor_role,
      metadata: { blocking_reasons, record: targetRecord }
    });
    return {
      status: "blocked",
      error_code: reconClosingStatus.open_critical_count > 0 ? "OPEN_CRITICAL_EXCEPTION" : "CLOSING_BLOCKED",
      message: `Daily closing diblokir untuk outlet '${outlet_id}' tanggal '${tanggal}'.`,
      data: { ...targetRecord },
      blocking_reasons
    };
  } else {
    logAuditEvent(db, {
      event_type: "CLOSING_VALIDATED",
      action: "VALIDATE_DAILY_CLOSING",
      entity_type: "DAILY_CLOSING",
      entity_id: closingId,
      outlet_id,
      result: "SUCCESS",
      actor_id: actor.actor_id,
      actor_name: actor.actor_name,
      actor_role: actor.actor_role,
      metadata: { record: targetRecord }
    });
    return {
      status: "success",
      message: `Daily closing valid dan READY untuk outlet '${outlet_id}' tanggal '${tanggal}'.`,
      data: { ...targetRecord }
    };
  }
}

export function executeDailyClosing(
  db: any,
  params: {
    outlet_id: string;
    tanggal: string;
    actor: ActorInfo;
    notes?: string;
  }
): { status: "success" | "error"; error_code?: string; message: string; data?: DailyClosingRecord; blocking_reasons?: string[] } {
  const { outlet_id, tanggal, actor, notes } = params;

  const existing = getDailyClosingRecord(db, outlet_id, tanggal);
  if (existing && existing.status === "CLOSED") {
    return {
      status: "success",
      message: "Daily closing sudah berstatus CLOSED.",
      data: existing
    };
  }

  const valRes = validateDailyClosing(db, { outlet_id, tanggal, actor });

  if (valRes.status === "blocked" || valRes.data?.status === "BLOCKED") {
    return {
      status: "error",
      error_code: valRes.error_code || "CLOSING_BLOCKED",
      message: "Proses closing diblokir karena syarat validasi belum terpenuhi.",
      data: valRes.data,
      blocking_reasons: valRes.blocking_reasons
    };
  }

  const record = getDailyClosingRecord(db, outlet_id, tanggal) || valRes.data!;
  const now = new Date().toISOString();

  record.status = "CLOSED";
  record.closed_at = now;
  record.closed_by = actor.actor_id || actor.actor_name || "SYSTEM";
  if (notes) record.notes = notes;
  record.updated_at = now;

  logAuditEvent(db, {
    event_type: "CLOSING_COMPLETED",
    action: "EXECUTE_DAILY_CLOSING",
    entity_type: "DAILY_CLOSING",
    entity_id: record.closing_id,
    outlet_id,
    result: "SUCCESS",
    actor_id: actor.actor_id,
    actor_name: actor.actor_name,
    actor_role: actor.actor_role,
    metadata: {
      closing_id: record.closing_id,
      outlet_id,
      tanggal,
      total_customer: record.total_customer,
      total_owner_deposit: record.total_owner_deposit,
      total_outlet_cash: record.total_outlet_cash,
      transaction_count: record.transaction_count
    }
  });

  return {
    status: "success",
    message: `Daily closing berhasil diselesaikan (CLOSED) untuk outlet '${outlet_id}' tanggal '${tanggal}'.`,
    data: record
  };
}

export function reopenDailyClosing(
  db: any,
  params: {
    outlet_id: string;
    tanggal: string;
    reason: string;
    actor: ActorInfo;
  }
): { status: "success" | "error"; error_code?: string; message: string; data?: DailyClosingRecord } {
  const { outlet_id, tanggal, reason, actor } = params;

  if (!actor || !actor.actor_role) {
    return { status: "error", error_code: "INVALID_ACTOR", message: "Identitas dan role actor wajib disertakan." };
  }

  const role = (actor.actor_role || "").toUpperCase();
  if (role !== "OWNER") {
    return {
      status: "error",
      error_code: "REOPEN_NOT_AUTHORIZED",
      message: "Akses ditolak. Wewenang Owner atau Super Admin diperlukan untuk meng-reopen daily closing."
    };
  }

  if (!reason || reason.trim().length === 0) {
    return {
      status: "error",
      error_code: "REASON_REQUIRED",
      message: "Alasan pembukaan kembali (reason) wajib diisi."
    };
  }

  const record = getDailyClosingRecord(db, outlet_id, tanggal);
  if (!record) {
    return {
      status: "error",
      error_code: "NOT_FOUND",
      message: `Record daily closing tidak ditemukan untuk outlet '${outlet_id}' tanggal '${tanggal}'.`
    };
  }

  if (record.status === "REOPENED") {
    return {
      status: "success",
      message: "Daily closing sudah dalam status REOPENED.",
      data: record
    };
  }

  if (record.status !== "CLOSED") {
    return {
      status: "error",
      error_code: "INVALID_STATE",
      message: `Tidak dapat meng-reopen closing dengan status '${record.status}'. Hanya status CLOSED yang dapat di-reopen.`
    };
  }

  const now = new Date().toISOString();
  const prevStatus = record.status;

  record.status = "REOPENED";
  record.reopened_at = now;
  record.reopened_by = actor.actor_id || actor.actor_name || "OWNER";
  record.reopen_reason = reason.trim();
  record.updated_at = now;

  logAuditEvent(db, {
    event_type: "CLOSING_REOPENED",
    action: "REOPEN_DAILY_CLOSING",
    entity_type: "DAILY_CLOSING",
    entity_id: record.closing_id,
    outlet_id,
    previous_status: prevStatus,
    new_status: "REOPENED",
    reason: reason.trim(),
    result: "WARNING",
    actor_id: actor.actor_id,
    actor_name: actor.actor_name,
    actor_role: actor.actor_role,
    metadata: {
      outlet_id,
      tanggal,
      reason: reason.trim()
    }
  });

  return {
    status: "success",
    message: `Periode daily closing outlet '${outlet_id}' tanggal '${tanggal}' berhasil dibuka kembali (REOPENED).`,
    data: record
  };
}

export function getDailyClosingStatus(db: any, outletId: string, tanggal: string) {
  const existing = getDailyClosingRecord(db, outletId, tanggal);
  if (existing) {
    return { status: "success", data: existing };
  }
  // Dry run validation
  const dummyActor: ActorInfo = { actor_id: "SYSTEM", actor_role: "SYSTEM" };
  const valRes = validateDailyClosing(db, { outlet_id: outletId, tanggal, actor: dummyActor });
  return { status: "success", data: valRes.data };
}
